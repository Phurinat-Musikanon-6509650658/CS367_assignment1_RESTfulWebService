package dev.phurinat.handytools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandytoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
