package dev.phurinat.handytools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadDatabase {

    public static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    CommandLineRunner initDatabase(StorageRepository repository) {
        return args -> {
            log.info("loading "+repository.save(new Storage("Harry Potter and the Philosopher's Stone", "Thammasart University Library", "2nd floor", "B312", true, "Phurinat Musikanon")));
            log.info("loading "+repository.save(new Storage("Deep Dark Fantasy", "Thammasart University Library", "2nd floor", "D444", true, "Akekykykyky")));
            log.info("loading"+repository.save(new Storage("Devil May Cry5","Thammasart University Library", "3th floor", "F894",false,null)));
            log.info("loading"+repository.save(new Storage("Top Gun Maverick","Thammasart University Library", "3th floor", "T300",true,"TeTonboy")));
            log.info("loading"+repository.save(new Storage("Percy Jackson and the Olympians","Thammasart University Library", "4th floor", "FK168",false,null)));
        };
    }
}
